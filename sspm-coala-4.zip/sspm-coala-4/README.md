# Star Student Planner
Student Planner app for Android.
Developed during my senior year of high school (Oct 2015 - Mar 2016).

### Quick Promo video: https://youtu.be/DRknMY7Rltk

**Description:**

Designed and created a mobile student planner app to help high school students, for Android mobile devices.
Distinguished app from competition with unique features such as efficient task addition, options for extracurricular activities, implementation of Google’s material design, and more.
